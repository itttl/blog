

## 官方运维文档
http://docs.ceph.org.cn/rados/operations/add-or-rm-osds/#removing-osds-manual
--------
## 日常操作文档
https://www.bookstack.cn/read/ceph_from_scratch/usage-ceph_commands.md
--------------------
## 创建集群
```
如果在某些地方碰到麻烦，想从头再来，可以用下列命令清除配置：

ceph-deploy purgedata {ceph-node} [{ceph-node}]
ceph-deploy forgetkeys
用下列命令可以连 Ceph 安装包一起清除：

ceph-deploy purge {ceph-node} [{ceph-node}]
如果执行了 purge ，你必须重新安装 Ceph 。

在管理节点上，进入刚创建的放置配置文件的目录，用 ceph-deploy 执行如下步骤。
```
### 创建集群。
```
ceph-deploy new {initial-monitor-node(s)}
例如：

ceph-deploy new node1
在当前目录下用 ls 和 cat 检查 ceph-deploy 的输出，应该有一个 Ceph 配置文件、一个 monitor 密钥环和一个日志文件。详情见 ceph-deploy new -h 。

把 Ceph 配置文件里的默认副本数从 3 改成 2 ，这样只有两个 OSD 也可以达到 active + clean 状态。把下面这行加入 [global] 段：

osd pool default size = 2
如果你有多个网卡，可以把 public network 写入 Ceph 配置文件的 [global] 段下。详情见网络配置参考。

public network = {ip-address}/{netmask}
安装 Ceph 。

ceph-deploy install {ceph-node} [{ceph-node} ...]
例如：

ceph-deploy install admin-node node1 node2 node3
ceph-deploy 将在各节点安装 Ceph 。 注：如果你执行过 ceph-deploy purge ，你必须重新执行这一步来安装 Ceph 。

配置初始 monitor(s)、并收集所有密钥：

ceph-deploy mon create-initial
完成上述操作后，当前目录里应该会出现这些密钥环：

{cluster-name}.client.admin.keyring
{cluster-name}.bootstrap-osd.keyring
{cluster-name}.bootstrap-mds.keyring
{cluster-name}.bootstrap-rgw.keyring
Note 只有在安装 Hammer 或更高版时才会创建 bootstrap-rgw 密钥环。
Note 如果此步失败并输出类似于如下信息 “Unable to find /etc/ceph/ceph.client.admin.keyring”，请确认 ceph.conf 中为 monitor 指定的 IP 是 Public IP，而不是 Private IP。
添加两个 OSD 。为了快速地安装，这篇快速入门把目录而非整个硬盘用于 OSD 守护进程。如何为 OSD 及其日志使用独立硬盘或分区，请参考 ceph-deploy osd 。登录到 Ceph 节点、并给 OSD 守护进程创建一个目录。

ssh node2
sudo mkdir /var/local/osd0
exit

ssh node3
sudo mkdir /var/local/osd1
exit
然后，从管理节点执行 ceph-deploy 来准备 OSD 。

ceph-deploy osd prepare {ceph-node}:/path/to/directory
例如：

ceph-deploy osd prepare node2:/var/local/osd0 node3:/var/local/osd1
最后，激活 OSD 。

ceph-deploy osd activate {ceph-node}:/path/to/directory
例如：

ceph-deploy osd activate node2:/var/local/osd0 node3:/var/local/osd1
用 ceph-deploy 把配置文件和 admin 密钥拷贝到管理节点和 Ceph 节点，这样你每次执行 Ceph 命令行时就无需指定 monitor 地址和 ceph.client.admin.keyring 了。

ceph-deploy admin {admin-node} {ceph-node}
例如：

ceph-deploy admin admin-node node1 node2 node3
ceph-deploy 和本地管理主机（ admin-node ）通信时，必须通过主机名可达。必要时可修改 /etc/hosts ，加入管理主机的名字。

确保你对 ceph.client.admin.keyring 有正确的操作权限。

sudo chmod +r /etc/ceph/ceph.client.admin.keyring
检查集群的健康状况。

ceph health
等 peering 完成后，集群应该达到 active + clean 状态。
```
---------------
## 扩展集群（扩容）
### 添加 OSD
```
你运行的这个三节点集群只是用于演示的，把 OSD 添加到 monitor 节点就行。

ssh node1
sudo mkdir /var/local/osd2
exit
然后，从 ceph-deploy 节点准备 OSD 。

ceph-deploy osd prepare {ceph-node}:/path/to/directory
例如：

ceph-deploy osd prepare node1:/var/local/osd2
最后，激活 OSD 。

ceph-deploy osd activate {ceph-node}:/path/to/directory
例如：

ceph-deploy osd activate node1:/var/local/osd2
一旦你新加了 OSD ， Ceph 集群就开始重均衡，把归置组迁移到新 OSD 。可以用下面的 ceph 命令观察此过程：

ceph -w
你应该能看到归置组状态从 active + clean 变为 active ，还有一些降级的对象；迁移完成后又会回到 active + clean 状态（ Control-C 退出）。
```
### 添加元数据服务器
```
至少需要一个元数据服务器才能使用 CephFS ，执行下列命令创建元数据服务器：
ceph-deploy mds create {ceph-node}
例如：

ceph-deploy mds create node1
```
### 添加 RGW 例程
```
要使用 Ceph 的 Ceph 对象网关组件，必须部署 RGW 例程。用下列方法创建新 RGW 例程：
ceph-deploy rgw create {gateway-node}
例如：
ceph-deploy rgw create node1
```
### 你可以用下面的命令检查法定人数状态：
```
ceph quorum_status --format json-pretty
```

### 创建bucket账户及key
```
radosgw-admin user create --uid testuser --display-name testuser --access-key 4HI3C4C7GPHSK7TAAXCX --secret-key 721LMOCxGMpA1RteV0Uy8gWU1FRLXydLJ141XSVK
s3cmd --access_key=4HI3C4C7GPHSK7TAAXCX --secret_key=721LMOCxGMpA1RteV0Uy8gWU1FRLXydLJ141XSVK --host=10.252.65.141:7480 --host-bucket="10.252.65.141:7480/%(bucket)" --no-ssl mb s3://test
s3cmd --access_key=4HI3C4C7GPHSK7TAAXCX --secret_key=721LMOCxGMpA1RteV0Uy8gWU1FRLXydLJ141XSVK --host=10.252.65.141:7480 --host-bucket="10.252.65.141:7480/%(bucket)" --no-ssl ls
```



https://www.cnblogs.com/happy1983/p/9246379.html
