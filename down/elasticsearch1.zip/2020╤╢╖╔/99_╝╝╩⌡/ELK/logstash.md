https://artifacts.elastic.co/downloads/logstash/logstash-6.8.1.zip
```
input{
   beats{
      port => 5044
   }
}
filter{
    if [com_name] == "k8s" {
       json {
          source => "message"
       }
       ruby {
          code => "event.set('time',(Time.parse(event.get('time')).to_f*1000000).to_i)"
       }
   }
      if [com_name] != "k8s" {
         grok{
            match => { "source" => "/var/lib/kubelet/pods/%{DATA:pod_id}/volumes/kubernetes.io~empty-dir/%{DATA:container_name}/%{DATA:org_name}/%{DATA:pro_name}/%{DATA:file_name}.log" }
        }
   }

   if [app_name] == "deeplearn" and [com_name] == "bettertrain" {
    grok{
        patterns_dir => "/data/opt/logstash/package/logstash-6.2.3/patterns"
        match => {"message" => "%{DISPATCHERLOG}"}
     }
   }
   else if [com_name] == "k8s" and [app_name] == "deeplearnbase"{
      grok{
        patterns_dir => "/data/opt/logstash/package/logstash-6.2.3/patterns"
        match => {"message" => "%{LOGBACKLOG}"}
      }
   }
   else if [com_name] != "k8s" {
      grok{
        patterns_dir => "/data/opt/logstash/package/logstash-6.2.3/patterns"
        match => {"message" => "%{LOGBACKLOG}"}
     }
   }
}

output{
        if [app_name] != "deeplearn" {
           elasticsearch{
                hosts => ["10.252.92.32:9200","10.252.92.34:9200","10.252.92.55:9200"]
                index => "%{[pod_id]}-%{[file_name]}"
                manage_template => false
           }
        }  else {
           elasticsearch{
                hosts => ["10.252.92.32:9200","10.252.92.34:9200","10.252.92.55:9200"]
                index => "%{[app_name]}"
                manage_template => false
           }
        }
}
```
