场景
----

IT公司统一AI平台的es集群需要改造重建，你先从这个事情入手整理输出具体的改造重建实施方案。具体问题可以联系沟通。 关于统一AI平台ELK集群规划用于存储平台应用的日志信息。根据客户的要求，日志存储周期为半年，预估容量为0.2T/天 * 180天 约为36T。当前再用的es集群容量只有接近3T，无法满足要求，所以需要重建。 es集群整改初步规划如下： 1、es中数据考虑为多副本形式存放，暂时规划es集群使用2台分布式服务器作为es的数据节点； 2、管理节点和logstash共用3台高端应用服务器； 3、es的数据节点采用多实例方式部署，每个实例使用两块物理硬盘； 4、每个es节点上规划占用内存不能超过系统内存的65%；

@琦哥，关于咱们es改造的其他要求(例如版本等)请安相关的人对接一下。

分布式服务器的配置如下： CPU：Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz (48核) MEM：375G 数据盘：5.5T * 12块(这里只是数据盘的容量，系统盘不做数据存储，不在考虑范围内)

常用跳板
========

87.77测试环境 92.27正式环境

老ES节点
--------

92.32
92.34
92.55
```
cluster.name: AIPlt
node.name: hebsjzx-zsaipt-jc-92-32
node.master: true
node.data: true
path.data: /data/els/data
path.logs: /data/els/logs
network.host: 10.252.92.32
http.port: 9200
discovery.zen.ping.unicast.hosts: ["10.252.92.32", "10.252.92.34","10.252.92.55"]
discovery.zen.minimum_master_nodes: 2
```
新版ES节点
----------

10.252.83.36 10.252.83.37

ES版本
------

```
#elasticsearch-6-8-10
https://www.elastic.co/cn/downloads/past-releases/elasticsearch-6-8-10
```

JDK版本
-------

JDK >= 1.8.0_131

架构规划
--------

端口9200-9210 9300-9310

一个Data节点3快6T盘 * 4

集群模式
--------

https://www.jianshu.com/p/74c0eca38035

## 集群配置
https://www.elastic.co/guide/cn/elasticsearch/guide/current/important-configuration-changes.html


机柜配置
--------

https://www.it610.com/article/1281006033203904512.htm``` 有两种方法，都是修改es的配置文件（%ES_HOME%/config/elasticsearch.yml）：

方法一、设置cluster.routing.allocation.same_shard.host: true。

这个设置是告诉es,将同一shard的primary shard和replica shard分步在不同的主机上（官方文档说按照不同的IP或主机名称来判断是否是同一主机）。这个值，ES默认是false。注意：如果是已经在生产环境使用的ES（每个机器的节点大于1个时），修改完配置重启节点时，可能会导致最后一个节点没有数据（因为最后一个节点在重启的时候，其他节点已经将他这个节点上的数据分配到同一机器上的另外一个节点）。

方法二、设置rack_id

设置如下：

node.rack_id: rack_1

cluster.routing.allocation.awareness.attributes: rack_id

 

Rack原义是货架，在这里是指机柜。这个rack_id其实可以自己定义, 上面配置的第二行就是如何定义这个名称。这样定义后，分片会被尽量的分片在不同的rack_id上面。如果rack_1和rack_2在不同的机器上，则就能实现将shard分布在不同的机器上的效果。定义这个名称后，如何查看索引是否分布在不同的机器上(第一个命令只记录了node_name,需要用第二个命令查询对应是那台机器）：

curl -XGET 'http://127.0.0.1:9250/index_name/_status?pretty=true'

curl -XGET 'http://127.0.0.1:9250/_cluster/nodes?pretty=true' ———————————————— 版权声明：本文为CSDN博主「oatye40020」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。 原文链接：https://blog.csdn.net/oatye40020/java/article/details/38761519```

集群配置信息
------------

```
cluster.name: iflytek-log-index
node.name: node1
path.data: /data/elasticsearch/data
path.logs: /data/elasticsearch/logs
node.master: true
node.data: true
network.host: 10.30.92.72
network.publish_host: 10.30.92.72
http.port: 9500
transport.tcp.port: 9501
http.cors.enabled: true
http.cors.allow-origin: "*"
discovery.zen.minimum_master_nodes: 1
discovery.zen.ping.unicast.hosts: ["10.30.92.72:9501","10.80.85.181:9501","10.80.86.179:9501"]
reindex.remote.whitelist: ["10.30.92.72:9500","10.80.85.181:9500","10.26.120.189:9500","10.80.86.179:9500"]
thread_pool:
    index:
        size: 5
        queue_size: 1000

```

其他配置
--------

```
elasticsearch的config文件夹里面有两个配置文 件：elasticsearch.yml和logging.yml，第一个是es的基本配置文件，第二个是日志配置文件，es也是使用log4j来记录日 志的，所以logging.yml里的设置按普通log4j配置文件来设置就行了。下面主要讲解下elasticsearch.yml这个文件中可配置的东西。

cluster.name: elasticsearch
配置es的集群名称，默认是elasticsearch，es会自动发现在同一网段下的es，如果在同一网段下有多个集群，就可以用这个属性来区分不同的集群。

node.name: "Franz Kafka"
节点名，默认随机指定一个name列表中名字，该列表在es的jar包中config文件夹里name.txt文件中，其中有很多作者添加的有趣名字。

node.master: true
指定该节点是否有资格被选举成为node，默认是true，es是默认集群中的第一台机器为master，如果这台机挂了就会重新选举master。

node.data: true
指定该节点是否存储索引数据，默认为true。

index.number_of_shards: 5
设置默认索引分片个数，默认为5片。

index.number_of_replicas: 1
设置默认索引副本个数，默认为1个副本。

path.conf: /path/to/conf
设置配置文件的存储路径，默认是es根目录下的config文件夹。

path.data: /path/to/data
设置索引数据的存储路径，默认是es根目录下的data文件夹，可以设置多个存储路径，用逗号隔开，例：
path.data: /path/to/data1,/path/to/data2

path.work: /path/to/work
设置临时文件的存储路径，默认是es根目录下的work文件夹。

path.logs: /path/to/logs
设置日志文件的存储路径，默认是es根目录下的logs文件夹

path.plugins: /path/to/plugins
设置插件的存放路径，默认是es根目录下的plugins文件夹

bootstrap.mlockall: true
设置为true来锁住内存。因为当jvm开始swapping时es的效率 会降低，所以要保证它不swap，可以把ES_MIN_MEM和ES_MAX_MEM两个环境变量设置成同一个值，并且保证机器有足够的内存分配给es。 同时也要允许elasticsearch的进程可以锁住内存，linux下可以通过`ulimit -l unlimited`命令。

network.bind_host: 192.168.0.1
设置绑定的ip地址，可以是ipv4或ipv6的，默认为0.0.0.0。


network.publish_host: 192.168.0.1
设置其它节点和该节点交互的ip地址，如果不设置它会自动判断，值必须是个真实的ip地址。

network.host: 192.168.0.1
这个参数是用来同时设置bind_host和publish_host上面两个参数。

transport.tcp.port: 9300
设置节点间交互的tcp端口，默认是9300。

transport.tcp.compress: true
设置是否压缩tcp传输时的数据，默认为false，不压缩。

http.port: 9200
设置对外服务的http端口，默认为9200。

http.max_content_length: 100mb
设置内容的最大容量，默认100mb

http.enabled: false
是否使用http协议对外提供服务，默认为true，开启。

gateway.type: local
gateway的类型，默认为local即为本地文件系统，可以设置为本地文件系统，分布式文件系统，hadoop的HDFS，和amazon的s3服务器，其它文件系统的设置方法下次再详细说。

gateway.recover_after_nodes: 1
设置集群中N个节点启动时进行数据恢复，默认为1。

gateway.recover_after_time: 5m
设置初始化数据恢复进程的超时时间，默认是5分钟。

gateway.expected_nodes: 2
设置这个集群中节点的数量，默认为2，一旦这N个节点启动，就会立即进行数据恢复。

cluster.routing.allocation.node_initial_primaries_recoveries: 4
初始化数据恢复时，并发恢复线程的个数，默认为4。

cluster.routing.allocation.node_concurrent_recoveries: 2
添加删除节点或负载均衡时并发恢复线程的个数，默认为4。

indices.recovery.max_size_per_sec: 0
设置数据恢复时限制的带宽，如入100mb，默认为0，即无限制。

indices.recovery.concurrent_streams: 5
设置这个参数来限制从其它分片恢复数据时最大同时打开并发流的个数，默认为5。

discovery.zen.minimum_master_nodes: 1
设置这个参数来保证集群中的节点可以知道其它N个有master资格的节点。默认为1，对于大的集群来说，可以设置大一点的值（2-4）

discovery.zen.ping.timeout: 3s
设置集群中自动发现其它节点时ping连接超时时间，默认为3秒，对于比较差的网络环境可以高点的值来防止自动发现时出错。

discovery.zen.ping.multicast.enabled: false
设置是否打开多播发现节点，默认是true。

discovery.zen.ping.unicast.hosts: ["host1", "host2:port", "host3[portX-portY]"]
设置集群中master节点的初始列表，可以通过这些节点来自动发现新加入集群的节点。

下面是一些查询时的慢日志参数设置
index.search.slowlog.level: TRACE
index.search.slowlog.threshold.query.warn: 10s
index.search.slowlog.threshold.query.info: 5s
index.search.slowlog.threshold.query.debug: 2s
index.search.slowlog.threshold.query.trace: 500ms

index.search.slowlog.threshold.fetch.warn: 1s
index.search.slowlog.threshold.fetch.info: 800ms
index.search.slowlog.threshold.fetch.debug:500ms
index.search.slowlog.threshold.fetch.trace: 200ms

http.cors.enabled   是否支持跨域，默认为false
http.cors.allow-origin  当设置允许跨域，默认为*,表示支持所有域名，如果我们只是允许某些网站能访问，那么可以使用正则表达式。比如只允许本地地址。 /https?:\/\/localhost(:[0-9]+)?/
http.cors.max-age   浏览器发送一个“预检”OPTIONS请求，以确定CORS设置。最大年龄定义多久的结果应该缓存。默认为1728000（20天）
http.cors.allow-methods 允许跨域的请求方式，默认OPTIONS,HEAD,GET,POST,PUT,DELETE
http.cors.allow-headers 跨域允许设置的头信息，默认为X-Requested-With,Content-Type,Content-Length
http.cors.allow-credentials 是否返回设置的跨域Access-Control-Allow-Credentials头，如果设置为true,那么会返回给客户端。
```
