#!/bin/bash
# zyl
# 2020年7月24日12:05:24
#curl -v -X DELETE 10.252.92.55:9200/53b4b06e-9cf0-11ea-a297-d0efc13b7525-templateweb.2020-06-04

for i in `cat index_size_top300.txt`
do
echo $i
curl -s -X DELETE 10.252.92.55:9200/$i >> delete_es_index.log
done
